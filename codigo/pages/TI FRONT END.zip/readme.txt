Bom dia, ou tarde, ou noite. Só volto aqui para avisar que o código em JS enviado contém as funções com teste local,
 e ao final do código, nos comentários, o protótipo das funções da entrega final. As funções finais não puderam ser
implementadas ainda pois depenedem da passagem de parâmetros de outras páginas, que serão feitas por outros usuários do grupo.
