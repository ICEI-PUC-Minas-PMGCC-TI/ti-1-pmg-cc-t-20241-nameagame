





document.addEventListener("DOMContentLoaded", function () {
    let solicitationsTable = document.getElementById("solicitationsTable").getElementsByTagName("tbody")[0];

    function addSolicitation(photoUrl, userName, text, userId) {
        let row = solicitationsTable.insertRow();

        let cellPhoto = row.insertCell(0);
        let cellName = row.insertCell(1);
        let cellText = row.insertCell(2);
        let cellActions = row.insertCell(3);

        cellPhoto.innerHTML = `<img src="${photoUrl}" alt="Foto" class="img-thumbnail">`;
        cellName.innerHTML = `<p>${userName}</p>`;
        cellText.innerHTML = `<p>${text}</p>`;

        let acceptButton = document.createElement("button");
        acceptButton.className = "btn btn-success me-2";
        acceptButton.textContent = "Aceitar";
        acceptButton.addEventListener("click", function () {
            alert(`Solicitação aceita. ID do usuário: ${userId}`);
            row.remove();
        });

        let rejectButton = document.createElement("button");
        rejectButton.className = "btn btn-danger";
        rejectButton.textContent = "Recusar";
        rejectButton.addEventListener("click", function () {
            row.remove();
        });

        cellActions.appendChild(acceptButton);
        cellActions.appendChild(rejectButton);
    }

    function generateSolicitations(count) {
        for (let i = 1; i <= count; i++) {
            let photoUrl = `assets/imagem1.jpg`; // Usando a imagem da pasta assets
            let userName = `Usuário ${i}`;
            let text = `Texto curto sobre a solicitação ${i}.`;
            let userId = i;
            addSolicitation(photoUrl, userName, text, userId);
        }
    }

    // Exemplo de uso da função
    generateSolicitations(12); // Chamada da função 

    
    
});

/*// assets/solicit.js

document.addEventListener('DOMContentLoaded', () => {
    const requestTableBody = document.getElementById('requestTableBody');
    const addRequestButton = document.getElementById('addRequest');

    // Carregar solicitações do Local Storage
    function loadRequests() {
        const requests = JSON.parse(localStorage.getItem('requests')) || [];
        requestTableBody.innerHTML = '';
        requests.forEach((request, index) => {
            addRequestToTable(request, index);
        });
    }

    // Adicionar solicitação à tabela
    function addRequestToTable(request, index) {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td><img src="${request.photo}" alt="Foto" class="img-thumbnail"></td>
            <td>${request.name}</td>
            <td>${request.text}</td>
            <td>
                <button class="btn btn-success me-2" onclick="acceptRequest(${index})">Aceitar</button>
                <button class="btn btn-danger" onclick="declineRequest(${index})">Recusar</button>
            </td>
        `;
        requestTableBody.appendChild(tr);
    }

    // Adicionar nova solicitação
    addRequestButton.addEventListener('click', () => {
        const photo = prompt('Digite o URL da foto:');
        const name = prompt('Digite o nome do usuário:');
        const text = prompt('Digite o texto da solicitação:');
        const requests = JSON.parse(localStorage.getItem('requests')) || [];
        const newRequest = { photo, name, text };
        requests.push(newRequest);
        localStorage.setItem('requests', JSON.stringify(requests));
        loadRequests();
    });

    // Funções de aceitar e recusar solicitação
    window.acceptRequest = function(index) {
        const requests = JSON.parse(localStorage.getItem('requests')) || [];
        alert(`Solicitação de ${requests[index].name} aceita!`);
        requests.splice(index, 1);
        localStorage.setItem('requests', JSON.stringify(requests));
        loadRequests();
    };

    window.declineRequest = function(index) {
        const requests = JSON.parse(localStorage.getItem('requests')) || [];
        alert(`Solicitação de ${requests[index].name} recusada.`);
        requests.splice(index, 1);
        localStorage.setItem('requests', JSON.stringify(requests));
        loadRequests();
    };

    // Carregar solicitações ao iniciar
    loadRequests();
});
*/ 



