OBS: O replit geralmente apresenta problemas com os 
arquivos, melhor testar localmente, caso tente visualizar 
pelo replit recomendo copiar html e jogar na barra de 
pesquisa do replit, caso continue dando erro, 
teste localmente.